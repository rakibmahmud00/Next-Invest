$(document).ready(function () {

    // mobile menu 
    $('.mobile-links li').click(function () {
        $(this).find('ul').slideToggle(300)
        $(this).find('i').toggleClass("rotate180")
    })

    $('.burger').click(function(){
        $('.mobile-nav').toggleClass('h-class')
    })

    $('.nav-closer').click(function(){
        $('.mobile-nav').toggleClass('h-class')
    })

    $(window).scroll(function(){
        $('.mobile-nav').addClass('h-class')
    })


});